public class BubbleSort {
    public static void sort(int[] arr) {
    int n = arr.length;
    boolean swapped;
    do {
        swapped = false;
        for (int i = 1; i < n; i++) {
            if (arr[i - 1] > arr[i]) {
                int temp = arr[i - 1];
                arr[i - 1] = arr[i];
                arr[i] = temp;
                swapped = true;
            }
        }
        //Introducing a bug This change causes the sorting algorithm to sort the array in descending order instead of ascending order. The test generator will detect this error and will return "Sorted: false".
         /*
        for (int i = 1; i < n; i++) {
                    if (arr[i - 1] < arr[i]) {
                        int temp = arr[i - 1];
                        arr[i - 1] = arr[i];
                        arr[i] = temp;
                       swapped = true;
                    }
                }
        */


    } while (swapped);
}
}
