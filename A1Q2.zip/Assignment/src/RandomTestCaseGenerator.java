import java.util.Arrays;
import java.util.Random;

public class RandomTestCaseGenerator {
    public static void main(String[] args) {
        Random rand = new Random();
        int[] arr;

        // test random arrays
        for (int i = 1; i <= 10; i++) {
            int size = rand.nextInt(10) + 1; // Random array size between 1 and 10
            arr = new int[size];
            for (int j = 0; j < size; j++) {
                arr[j] = rand.nextInt(50); // Random integers between 0 and 49
            }

            System.out.println("Random Test Case " + i + ":");
            System.out.println("Input Array: " + Arrays.toString(arr));

            BubbleSort.sort(arr);

            System.out.println("Sorted Array: " + Arrays.toString(arr));
            System.out.println("Sorted: " + isSorted(arr) + "\n");
        }
    }

    public static boolean isSorted(int[] arr) {
        for (int i = 1; i < arr.length; i++) {
            if (arr[i - 1] > arr[i]) {
                return false;
            }
        }
        return true;
    }
}
