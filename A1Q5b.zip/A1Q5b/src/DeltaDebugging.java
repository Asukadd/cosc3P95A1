public class DeltaDebugging {

    public static void main(String[] args) {
        //input
        String[] inputs = {
                "abcdefG1",
                "CCDDEExy",
                "1234567b",
                "8665"
        };

        for (String input : inputs) {
            String minimal = deltaDebugging(input);
            System.out.println("Minimal for '" + input + "': '" + minimal+ "'");
        }//output
    }

    public static String deltaDebugging(String inputStr) {
        int low = 0;
        int high = inputStr.length();

        if (!testInput(inputStr)) {
            return "No found";
        }

        while (high - low > 1) {
            int mid = (low + high) / 2;
            //Split the input string into two parts
            String prefix = inputStr.substring(0, mid);
            String suffix = inputStr.substring(mid);

            if (testInput(prefix)) {
                high = mid;//test first half
            } else {
                low = mid;//test second half
            }
        }

        return inputStr.substring(low, high);
    }
//Checks the characters in the input string and returns true if the output of numeric characters is found to be incorrect, otherwise returns false
    public static boolean testInput(String inputStr) {
        String outputStr = processString(inputStr);
        char[] chars = inputStr.toCharArray();

        for (char c : chars) {
            if (Character.isDigit(c) && outputStr.chars().filter(o -> o == c).count() != 2) {
                return true;
            }
        }
        return false;
    }

    public static String processString(String inputStr) {
        StringBuilder string = new StringBuilder();

        for (char c : inputStr.toCharArray()) {
            if (Character.isUpperCase(c)) {
                // If it's an uppercase letter, convert it to lowercase
                string.append(Character.toLowerCase(c));
            } else if (Character.isLowerCase(c)) {
                // If it's a lowercase letter, convert it to uppercase
                string.append(Character.toUpperCase(c));
            } else {
                // If it is a number or other character, leave it unchanged
                string.append(c);
            }
        }

        return string.toString();
    }
}